# volatility_surface.py

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.interpolate import CubicSpline
from scipy.interpolate import UnivariateSpline

# --- SVI 模型 (GARCH 代理) ---
# (保持 SVI 代码不变，虽然我们现在不用它，但为了兼容性保留)

def svi_raw_formula(k, params):
    a, b, rho, m, sigma = params
    b = max(0, b)
    sigma = max(1e-6, sigma)
    rho = max(-0.9999, min(0.9999, rho))
    return a + b * (rho * (k - m) + np.sqrt((k - m)**2 + sigma**2))

def objective_function(params, k_market, w_market):
    w_model = svi_raw_formula(k_market, params)
    return np.sum((w_model - w_market)**2)

def fit_svi_surface(moneyness_points: list, w_points: list):
    df = pd.DataFrame({'k': moneyness_points, 'w': w_points})
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    df_agg = df.groupby('k')['w'].mean().reset_index().sort_values('k')
    if len(df_agg) < 5: return None
    k_market = df_agg['k'].values
    w_market = df_agg['w'].values
    params_0 = [np.min(w_market), 0.1, -0.5, np.mean(k_market), 0.1]
    bounds = ((1e-6, None), (1e-6, None), (-0.9999, 0.9999), (np.min(k_market), np.max(k_market)), (1e-6, None))
    try:
        res = minimize(objective_function, x0=params_0, args=(k_market, w_market), method='L-BFGS-B', bounds=bounds)
        return res.x if res.success else None
    except: return None

def get_vol_from_svi_params(svi_params, k, T):
    if svi_params is None or np.isnan(k) or T <= 1e-9: return 0.20
    w = svi_raw_formula(k, svi_params)
    return max(0.05, min(np.sqrt(max(w, 1e-9) / T), 1.5))

# --- Cubic Spline 模型 (优化版) ---

def fit_spline_surface(moneyness_points: list, iv_points: list, weights: list = None):
    """
    使用平滑样条拟合
    """
    df = pd.DataFrame({'x': moneyness_points, 'y': iv_points})
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    df = df.sort_values('x')
    
    # 去重取平均
    df_agg = df.groupby('x')['y'].mean().reset_index()
    x = df_agg['x'].values
    y = df_agg['y'].values
    
    n = len(x)
    if n < 4:
        if n < 2: return None
        return np.poly1d(np.polyfit(x, y, 1))

    try:
        # (!!!) 优化：稍微增大平滑因子，使 Slope 更稳定
        # 原来是 2e-4，现在改为 5e-4。
        # 这会牺牲极少量的 IV 拟合精度，换取更“干净”的一阶导数。
        s_factor = len(x) * 5e-4 
        
        spline = UnivariateSpline(x, y, k=3, s=s_factor)
        return spline
    except:
        return CubicSpline(x, y, extrapolate=True)

def get_vol_and_slope_from_spline(spline_model, moneyness: float): # -> (vol, slope)
    """
    仅返回 Vol 和 Slope (一阶导)，移除不稳定的 Curvature
    """
    if spline_model is None or np.isnan(moneyness):
        return 0.20, 0.0
    
    try:
        # 1. Vol
        vol = float(spline_model(moneyness))
        
        # 2. Slope (有限差分)
        eps = 0.01
        vol_up = float(spline_model(moneyness + eps))
        vol_down = float(spline_model(moneyness - eps))
        slope = (vol_up - vol_down) / (2 * eps)
        
    except:
        return 0.20, 0.0
        
    return max(0.05, min(vol, 1.5)), slope